=======
License
=======

more-itertools is under the MIT License. See the LICENSE file.

Conditions for Contributors
===========================

By contributing to this software project, you are agreeing to the following
terms and conditions for your contributions: First, you agree your
contributions are submitted under the MIT license. Second, you represent you
are authorized to make the contributions and grant the license. If your
employer has rights to intellectual property that includes your contributions,
you represent that you have received permission to make contributions and grant
the required license on behalf of that employer.
