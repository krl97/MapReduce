=======
Testing
=======

To run install dependencies and run tests, use this command::

    python setup.py test

Multiple Python Versions
========================

To run the tests on all the versions of Python more-itertools supports, install
tox::

    pip install tox

Then, run the tests::

    tox
